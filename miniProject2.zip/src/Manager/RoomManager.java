package Manager;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import Client.SocketClient;

public class RoomManager {
	Map<String, SocketClient> chatRoom = Collections.synchronizedMap(new HashMap<>()); // ä�� Map
	
	public void addSocketClient(String key, HashMap<String, SocketClient> clientList) {
		chatRoom.put(key, clientList.get(key));
		System.out.println("입장: " + clientList.get(key));
		System.out.println("현재 채팅자 수: " + clientList.size() + "\n");
	}
	
	public int removeSocketClient(String key, HashMap<String, SocketClient> clientList) {
		chatRoom.remove(key);
		System.out.println("퇴장: " + clientList.get(key));
		System.out.println("현재 채팅자 수: " + clientList.size() + "\n");
		return clientList.size();
	}
}