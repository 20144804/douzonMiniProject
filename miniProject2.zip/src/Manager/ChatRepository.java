package Manager;

public class ChatRepository {
	
}