package util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Properties;

import lombok.Data;
import lombok.Getter;

public class Define {
	Properties properties;
	public static String ip;
	public static int port;
	public static String imagePath;
	public static String memberPath;
	public static String chatPath;
	
	public Define() {
		File directory = new File("./");
		properties = readProperties("TcpIp.properties");
		ip = properties.getProperty("ip");
		port = Integer.parseInt(properties.getProperty("port"));
		imagePath = properties.getProperty("imagePath");
		memberPath = properties.getProperty("memberPath");
		chatPath = properties.getProperty("chatPath");
	}
	
	public Properties readProperties(String propFileName) {
		Properties prop = new Properties();
		InputStream is = getClass().getResourceAsStream(propFileName);
		
		try {
			if (is != null) {
				prop.load(is);
				return prop;
			} else {
				throw new FileNotFoundException("프로퍼티 파일 '" + propFileName + "'을 찾을 수 없습니다.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}

