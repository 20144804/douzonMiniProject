package util;

public class Protocol {
	public static final String Login = "login";						// 로그인
	public static final String Logout = "logout";					// 로그아웃
	public static final String CreateRoom = "createRoom";			// 채팅방 생성
	public static final String ExitRoom = "exitRoom";				// 채팅방 나가기
	public static final String ViewRooms = "viewRooms";				// 채팅방 목록
	public static final String ViewRoomMember= "viewRoomMember";	// 현재 채팅방 멤버 목록
	public static final String Whisper = "whisper";					// 귓속말
	public static final String ViewFiles = "viewFiles";
	public static final String View6 = "";
	public static final String View7 = "";
}