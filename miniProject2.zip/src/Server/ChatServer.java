package Server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.FileAlreadyExistsException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.Stream;
//추가
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.json.JSONObject;

import Client.SocketClient;
import Entity.Member;
import Manager.RoomManager;
import util.Define;

public class ChatServer {
	// 필드
	ServerSocket serverSocket; // 서버 소켓
	public ExecutorService threadPool = Executors.newFixedThreadPool(100); // 클라이언트 연결, 소켓을 처리하는 스레드풀
	HashMap<String, SocketClient> chatRoom; // 대기실
	Map<String, HashMap<String, SocketClient>> rooms; // 채팅방
	RoomManager roomManger;
	List<Member> memberList = null;
	Map<String, Member> memberMap = null;
	Define def = new Define(); // 파일?
	private static final String WATTING = "wattingroom";
	final String MEMBER_FILE_NAME = Define.memberPath;
	// 추가
	private static final String CHATTING_DIRECTORY_NAME = "c:\\miniProject";
	private static final String TXT = ".txt";

	public ChatServer() {
		chatRoom = new HashMap<String, SocketClient>();
		rooms = new HashMap<String, HashMap<String, SocketClient>>();

		Collections.synchronizedMap(chatRoom);
		Collections.synchronizedMap(rooms);
	}

	// 추가 디렉토리,파일 생성, folderName:방이름 이름정도?
	public void mkdirAndFile(String folderName) throws FileAlreadyExistsException, IOException {
		String filename = CHATTING_DIRECTORY_NAME +  "\\"+ folderName + "\\chatting.txt";

		try {
			File directory = new File(CHATTING_DIRECTORY_NAME + "\\"+folderName);
			File file = new File(filename);

			if (!directory.exists()) {
				directory.mkdir();
				if (!file.exists()) {
					file.createNewFile();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 추가 방에 입장시 개인 채팅 기록
	public void mkPrivateFile(SocketClient sender)
			throws FileAlreadyExistsException, IOException {
		String filename = CHATTING_DIRECTORY_NAME + "\\" + sender.currentRoomName + "\\chatting" + sender.chatName + TXT;

		try {
			File file = new File(filename);

			if (!file.exists()) {
				file.createNewFile();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	// 추가 파일에 채팅 내용 저장
	public void writeChattingAll(SocketClient sender, String message) throws FileAlreadyExistsException, IOException {
		LocalDateTime now = LocalDateTime.now();
		String formatedNow = now.format(DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss"));

		File dir = new File("CHATTING_DIRECTORY_NAME"+"\\" + sender.currentRoomName);
		String[] fileNames = dir.list((f,name)->name.endsWith(".txt"));
		for (int i = 0; i < fileNames.length; i++) {

			try {
			File file = new File(CHATTING_DIRECTORY_NAME + "\\" + sender.currentRoomName + "\\"+fileNames[i]);
			FileWriter fileWriter = new FileWriter(file, true);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write("(" + formatedNow + ")" + sender.chatName + "@" + sender.clientIp + ": " + message);
			bufferedWriter.write("\r\n");
			fileWriter.close();
			
			bufferedWriter.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
	}
	
	// 추가 귓속말 저장
	public void writeWisper(SocketClient sender, String receiver, String message) {
		File file = new File(CHATTING_DIRECTORY_NAME + "\\" + sender.currentRoomName + "\\chatting"+TXT);
		File filePrivate = new File(CHATTING_DIRECTORY_NAME + "\\" + sender.currentRoomName + "\\chatting"+sender.chatName+TXT);
		File filePrivateReceiver = new File(CHATTING_DIRECTORY_NAME + "\\" + sender.currentRoomName + "\\chatting"+receiver+TXT);
		LocalDateTime now = LocalDateTime.now();
		String formatedNow = now.format(DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss"));

		try {
			//all
			FileWriter fileWriter = new FileWriter(file, true);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write("(" + formatedNow + ")" + sender.chatName + "@" + sender.clientIp + "=>" + receiver+ ": " + message);
			bufferedWriter.write("\r\n");
			fileWriter.close();
			
			//sender
			fileWriter = new FileWriter(filePrivate, true);
			bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write("(" + formatedNow + ")" + sender.chatName + "@" + sender.clientIp +"=>" + receiver+ ": " + message);
			bufferedWriter.write("\r\n");
			fileWriter.close();
			
			//receiver
			fileWriter = new FileWriter(filePrivateReceiver, true);
			bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write("(" + formatedNow + ")" + sender.chatName + "@" + sender.clientIp +"=>" + receiver+ ": " + message);
			bufferedWriter.write("\r\n");
			fileWriter.close();
			
			bufferedWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 추가 디렉토리 삭제
//	public void removeDir(int num) {
//		if(num==0) {
//			String key = socketClient.chatName + "@" + socketClient.clientIp
//		}
//			
//	}

	// 추가 방 삭제
//	public void removeRoom(String roomName, SocketClient socketClient) {
//		HashMap<String, SocketClient> client_list = new HashMap<String, SocketClient>();
//		String key = socketClient.chatName + "@" + socketClient.clientIp;
//		if(roomManger.removeSocketClient(key, client_list))
//			
//	}

	@SuppressWarnings("unchecked")
	private void loadMember() {
		try {
			File file = new File(MEMBER_FILE_NAME);
			if (file.exists() && file.length() != 0) {
				ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
				memberList = (List<Member>) in.readObject();
				// 확인용
				memberList.stream().forEach(s -> System.out.println(s.toString()));
				memberMap = memberList.stream().collect(
						Collectors.toMap(m -> m.getUid(), m -> m, (oldValue, newValue) -> newValue, TreeMap::new));
				// 확인용
				System.out.println(memberMap);
				in.close();
			} else {
				memberList = new ArrayList<>();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void saveMember() {
		try {
			File file = new File(MEMBER_FILE_NAME);
			ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
			out.writeObject(memberList);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 메소드: 서버 시작
	public void start() throws IOException {
		roomManger = new RoomManager();
		loadMember();
		serverSocket = new ServerSocket(Define.port);
		System.out.println("[서버] 시작됨");

		Thread thread = new Thread(() -> {
			try {
				while (true) {
					Socket socket = serverSocket.accept();
					SocketClient sc = new SocketClient(this, socket);
				}
			} catch (IOException e) {
			}
		});
		thread.start();
	}

	// 메소드: 클라이언트 연결시 SocketClient 생성 및 추가
	public void addSocketClient(SocketClient socketClient) {
		String key = socketClient.chatName + "@" + socketClient.clientIp;
		chatRoom.put(key, socketClient);
		System.out.println("입장: " + key);
		System.out.println("현재 채팅자 수: " + chatRoom.size() + "\n");
	}

	// 메소드: 클라이언트 연결 종료시 SocketClient 제거
	public void removeSocketClient(SocketClient socketClient) {
		String key = socketClient.chatName + "@" + socketClient.clientIp;
		chatRoom.remove(key);
		System.out.println("나감: " + key);
		System.out.println("현재 채팅자 수: " + chatRoom.size() + "\n");

	}

	// 추가 writeWisper
	public void sendWhisper(SocketClient sender, String message) {
		String[] data = message.split(" ", 2);
		String name = data[0];
		String whisper = data[1];

		System.out.println(name + whisper);

		JSONObject root = new JSONObject();
		root.put("clientIp", sender.clientIp);
		root.put("chatName", sender.chatName);
		root.put("message", whisper);
		String json = root.toString();

		Collection<SocketClient> socketClients = chatRoom.values();
		for (SocketClient sc : socketClients) {
			if (sc == sender)
				continue;

			
			if (sc.chatName.equals(name)) {
				sc.send(json);
				// here
				writeWisper(sender, name, message);
			}

		}
		System.out.println(
				"<" + sender.chatName + "@" + sender.clientIp + "> 님이 " + name + "에게 " + message + "의 메시지를 귓속말 보냈습니다.");
	}

	public void sendFile(SocketClient sender, String message) {
		JSONObject root = new JSONObject();
		root.put("clientIp", sender.clientIp);
		root.put("chatName", sender.chatName);
		root.put("message", message);
		String json = root.toString();

		chatRoom.values().stream().filter(socketClient -> socketClient != sender)
				.forEach(socketClient -> socketClient.send(json));
	}

	public void sendToOneSelf(SocketClient sender, String message) {
		JSONObject root = new JSONObject();
		root.put("clientIp", sender.clientIp);
		root.put("chatName", sender.chatName);
		root.put("message", message);
		String json = root.toString() + "채팅방이 생성되었습니다.";

		chatRoom.values().stream().filter(socketClient -> socketClient == sender)
				.forEach(socketClient -> socketClient.send(json));
	}

	// 메소드: 모든 클라이언트에게 메시지 보냄
	// 추가 예외처리, 메세지 저장
	public void sendToAll(SocketClient sender, String message) throws FileAlreadyExistsException, IOException {
		JSONObject root = new JSONObject();
		root.put("clientIp", sender.clientIp);
		root.put("chatName", sender.chatName);
		root.put("message", message);
		String json = root.toString();

		chatRoom.values().stream().filter(socketClient -> socketClient != sender)
				.forEach(socketClient -> socketClient.send(json));
		System.out.println("<" + sender.chatName + "@" + sender.clientIp + "> " + message);
		// 추가
		writeChattingAll(sender, message);
	}

	// 메소드: 서버 종료
	public void stop() {
		try {
			serverSocket.close();
			threadPool.shutdownNow();
			chatRoom.values().stream().forEach(sc -> sc.close());
			System.out.println("[서버] 종료됨 ");
		} catch (IOException e1) {
		}
	}

	public synchronized void registerMember(Member member) throws Member.ExistMember {
		if (true == memberList.stream().anyMatch(m -> member.getUid().equals(m.getUid()))) {
			throw new Member.ExistMember("[" + member.getUid() + "] 아이디가 존재합니다");
		}
		memberList.add(member);
		saveMember();
	}

	public synchronized Member findByUid(String uid) throws Member.NotExistUidPwd {
		Member findMember = Member.builder().uid(uid).build();
		int index = memberList.indexOf(findMember);
		if (-1 == index) {
			throw new Member.NotExistUidPwd("[" + uid + "] 아이디가 존재하지 않습니다");
		}
		return memberList.get(index);
	}

	// 추가 mkdirAndFile:디렉, 파일 생성, 방이름 추가, mkPrivateFile 개인 채팅 파일
	public void createRoom(String roomName, SocketClient socketClient) throws FileAlreadyExistsException, IOException {
		if (!rooms.containsKey(roomName)) {
			HashMap<String, SocketClient> client_list = new HashMap<String, SocketClient>();
			String key = socketClient.chatName + "@" + socketClient.clientIp;
			client_list.put(key, socketClient);
			rooms.put(roomName, client_list);
			if (chatRoom.containsKey(key))
				chatRoom.remove(key);
			rooms.put(WATTING, chatRoom);
			roomManger.addSocketClient(key, client_list);
			printServerLog("현재 채팅방 수: " + rooms.size());
			// 추가
			mkdirAndFile(roomName);
			mkPrivateFile(socketClient);
			socketClient.currentRoomName = roomName;
		} else {
			sendToOneSelf(socketClient, "이미 방이 존재합니다.");
		}
	}

	private void printServerLog(String msg) {
		System.out.println(msg);
	}

	// 메소드: 메인
	public static void main(String[] args) {
		try {
			ChatServer chatServer = new ChatServer();
			chatServer.start();

			System.out.println("----------------------------------------------------");
			System.out.println("서버를 종료하려면 q를 입력하고 Enter.");
			System.out.println("----------------------------------------------------");

			Scanner scanner = new Scanner(System.in);
			while (true) {
				String key = scanner.nextLine();
				if (key.equals("q"))
					break;
			}
			scanner.close();
			chatServer.stop();
		} catch (IOException e) {
			System.out.println("[서버] " + e.getMessage());
		}
	}
}