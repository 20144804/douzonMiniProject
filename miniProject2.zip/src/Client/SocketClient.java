package Client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

import org.json.JSONObject;

import Entity.Member;
import Server.ChatServer;

public class SocketClient {
	// 필드
	ChatServer chatServer;
	Socket socket;
	DataInputStream dis;
	DataOutputStream dos;
	public String clientIp;
	public String chatName;
	//추가
	public String currentRoomName;

	// 생성자
	public SocketClient(ChatServer chatServer, Socket socket) {
		try {
			this.chatServer = chatServer;
			this.socket = socket;
			this.dis = new DataInputStream(socket.getInputStream());
			this.dos = new DataOutputStream(socket.getOutputStream());
			InetSocketAddress isa = (InetSocketAddress) socket.getRemoteSocketAddress();
			this.clientIp = isa.getHostName();
			receive();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 메소드: JSON 받기
	public void receive() {
		chatServer.threadPool.execute(() -> {
			try {
				boolean stop = false;
				while (true != stop) {
					int status = 1;
					String receiveJson = dis.readUTF();

					JSONObject jsonObject = new JSONObject(receiveJson);
					String command = jsonObject.getString("command");

					switch (status) {
						case 1:
							switch (command) {
							case "login":
								login(jsonObject);
								stop = true;
								break;
							case "passwdSearch":
								passwdSearch(jsonObject);
								stop = true;
								break;
							}
							break;
						case 2:
							switch (command) {
							case "createRoom":
								String roomName = jsonObject.getString("data");
								chatServer.createRoom(roomName, this);
								break;
							case "incoming":
								this.chatName = jsonObject.getString("data");
								chatServer.sendToAll(this, "들어오셨습니다.");
								chatServer.addSocketClient(this);
								break;
							case "message":
								String message = jsonObject.getString("data");
								chatServer.sendToAll(this, message);
								break;
							case "whisper":
								String whispermessage = jsonObject.getString("data");
								chatServer.sendWhisper(this, whispermessage);
								break;
							case "file":
								String filemessage = jsonObject.getString("data");
								chatServer.sendFile(this, filemessage);
								break;
							}
					}
					break;

				}
			} catch (IOException e) {
				try {
					chatServer.sendToAll(this, "나가셨습니다.");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				chatServer.removeSocketClient(this);
			}
		});

	}

	private void login(JSONObject jsonObject) {
		String uid = jsonObject.getString("uid");
		String pwd = jsonObject.getString("pwd");
		JSONObject jsonResult = new JSONObject();

		jsonResult.put("statusCode", "-1");
		jsonResult.put("message", "로그인 아이디가 존재하지 않습니다");

		try {
			Member member = chatServer.findByUid(uid);
			if (null != member && pwd.equals(member.getPwd())) {
				jsonResult.put("statusCode", "0");
				jsonResult.put("message", "로그인 성공");
			}
		} catch (Member.NotExistUidPwd e) {
			e.printStackTrace();
		}

		send(jsonResult.toString());

		close();
	}

	private void passwdSearch(JSONObject jsonObject) {
		String uid = jsonObject.getString("uid");
		JSONObject jsonResult = new JSONObject();

		jsonResult.put("statusCode", "-1");
		jsonResult.put("message", "로그인 아이디가 존재하지 않습니다");

		try {
			Member member = chatServer.findByUid(uid);
			if (null != member) {
				jsonResult.put("statusCode", "0");
				jsonResult.put("message", "비밀번호 찾기 성공");
				jsonResult.put("pwd", member.getPwd());
			}
		} catch (Member.NotExistUidPwd e) {
			e.printStackTrace();
		}

		send(jsonResult.toString());

		close();
	}

	// 메소드: JSON 보내기
	public void send(String json) {
		try {
			dos.writeUTF(json);
			dos.flush();
		} catch (IOException e) {
		}
	}

	// 메소드: 연결 종료
	public void close() {
		try {
			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}