package Main;
import java.io.IOException;

import Client.ChatClient;

public class ClientMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		new ChatClient().connect();
	}
}