package Main;
import java.io.IOException;

import Server.ChatServer;

public class ServerMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		new ChatServer().start();
	}
}